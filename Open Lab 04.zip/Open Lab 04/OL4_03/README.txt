Instruktioner:

1) Ni har en nästan komplett HTML-fil att tillgå. Denna får ni redigera hur ni vill. Däremot finns det en bra grund att utgå ifrån, men som kommer behöva utökas.
2) Skapa en stilmall och koppla den till ert HTML-dokument.
3) Ni ska försöka återskapa det som finns i exempelbilden. Ni behöver inte ha exakt samma färger, men det ska vara skilda färger så vi kan se skillnad på allting som i exempelbilden.
4) Nedan finner ni lite nötter som vägledning.

Vägledande nötter:

* Varje rad har fjärdedel av webbläsarfönstret som höjd.
* Eftersom vissa raders barn skiljer sig i hur dom är placerade kommer ni behöva lägga till en klass eller id så ni kan styra detta i CSS.
* Eftersom vissa lådor skiljer sig i färg kommer ni behöva lägga till en klass eller ett id så ni kan styra detta i CSS.