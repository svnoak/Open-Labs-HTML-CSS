Instruktioner:

1) Ni har en nästan komplett HTML-fil. Det som saknas är en sk. "favicon", bilden finner ni i mappen "images".
2) Ni behöver skapa en stilmall och försöka efterlikna exempelbilden så mycket som möjligt.
3) I listan nedan finner ni lite vägledning.

Vägledning:

* Färger som används: lightgreen, darkgreen, darksalmon, whitesmoke.
* Bilden tillsammans med listan är centrerade både horisontellt och vertikalt. Om allting skulle råka placeras i överkant (inte centrerat) så kan ni experimentera med att ge er "container" någon höjd.
* Rutan som bilden och listan befinner sig i har en fast bredd på 500 pixlar.
* Vad gäller både rubriken och listan används padding för att låta bakgrundsfärgen ta mer plats, sedan tar vi bort vissa marginaler så det ser ut som att dom sitter ihop.
* Bilden läggs till genom background-image.