Instruktioner:

1) Ni har en nästan komplett HTML-fil. I denna behöva ni lägga in en <link> som inkluderar typsnittet Oswald från Google Fonts.
2) Ni måste sedan skapa en stilmall och efterlikna det som syns i videon. Nedan finner ni en lista över saker att notera.

Nötter:

* Ingen av länkarna är "underlined" samt att dom har vit färg oavsett om man besökt länken tidigare eller inte (tips: sök på pseudoklassen "visited").
* När besökaren har muspekaren ovanför en länk blir färgen "skyblue".
* Navigationen har en höjd på 150 pixlar.
* Texten i navigationen är centrerad både horisontellt och vertikalt.
* Även fast texten är centrerad går hela "lådan" att klicka på.

Tips:

* När ni gör en flexbox av era länkar, om dom inte får samma bredd så kan ni pröva att ange "flex-basis: 0;" - varför behövs detta tror ni?
